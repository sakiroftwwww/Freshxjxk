class List {
    constructor() {}
}
